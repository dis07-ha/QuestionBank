from flask import Flask, render_template, request, redirect, url_for, send_file
from flask_pymongo import PyMongo
from bson.objectid import ObjectId
import io
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from PyPDF2 import PdfWriter, PdfReader


app = Flask(__name__)

# MongoDB configuration
app.config["MONGO_URI"] = "mongodb://localhost:27017/questionsdb"
mongo = PyMongo(app)

users = {
    'employee1': 'pass1',
    'employee2': 'pass2'
}

@app.route('/')
def home():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    employee_id = request.form['employee_id']
    password = request.form['password']

    if employee_id in users and users[employee_id] == password:
        # Successful login, redirect to a dashboard or another page
        return redirect(url_for('index'))
    else:
        # Invalid credentials, redirect back to the login page with a message
        return render_template('login.html', message='Invalid credentials. Please try again.')

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/page1', methods=['GET', 'POST'])
def page1():
    if request.method == 'POST':
        question_text = request.form.get('question')
        if question_text:
            mongo.db.questions.insert_one({'text': question_text, 'important': False})
            return redirect(url_for('page1'))
    return render_template('page1.html')

@app.route('/saved_questions')
def saved_questions():
    questions = mongo.db.questions.find()
    return render_template('saved_questions.html', questions=questions)

@app.route('/toggle_important/<id>')
def toggle_important(id):
    question = mongo.db.questions.find_one({'_id': ObjectId(id)})
    if question:
        current_important = question.get('important', False)
        mongo.db.questions.update_one({'_id': ObjectId(id)}, {'$set': {'important': not current_important}})
    return redirect(url_for('saved_questions'))

@app.route('/delete_question/<id>')
def delete_question(id):
    mongo.db.questions.delete_one({'_id': ObjectId(id)})
    return redirect(url_for('saved_questions'))

@app.route('/page2', methods=['GET', 'POST'])
def page2():
    if request.method == 'POST':
        selected_questions = request.form.getlist('questions')
        return redirect(url_for('generate_pdf_route', questions=selected_questions))
    questions = mongo.db.questions.find()
    return render_template('page2.html', questions=questions)

@app.route('/question_paper', methods=['GET', 'POST'])
def question_paper():
    questions_ids = request.args.getlist('questions')
    questions = [mongo.db.questions.find_one({'_id': ObjectId(q_id)}) for q_id in questions_ids]
    if request.method == 'POST':
        return generate_pdf(questions)
    return render_template('question_paper.html', questions=questions)


@app.route('/generate_pdf')
def generate_pdf_route():
    questions_ids = request.args.getlist('questions')
    questions = [mongo.db.questions.find_one({'_id': ObjectId(q_id)}) for q_id in questions_ids]
    return generate_pdf(questions)


def generate_pdf(questions):
    # Read the existing pattern PDF
    existing_pdf = PdfReader(open("static/paperr.pdf", "rb"))
    output = PdfWriter()

    # Create a packet to hold the new PDF with questions
    packet = io.BytesIO()
    can = canvas.Canvas(packet, pagesize=letter)

    # Draw the selected questions on the PDF
    text = can.beginText(50, 550)  # Adjust the Y coordinate as per your template design
    text.setFont("Helvetica", 12)
    for idx, question in enumerate(questions, start=1):
        text.textLine(f"{idx}. {question['text']}")
    can.drawText(text)
    can.save()

    packet.seek(0)
    new_pdf = PdfReader(packet)

    # Combine the pattern PDF and the new PDF
    page = existing_pdf.pages[0]
    packet_page = new_pdf.pages[0]
    page.merge_page(packet_page)

    output.add_page(page)

    # Save the new PDF to a file
    output_stream = io.BytesIO()
    output.write(output_stream)
    output_stream.seek(0)

    return send_file(output_stream, as_attachment=True, download_name='question_paper.pdf', mimetype='application/pdf')


if __name__ == '__main__':
    app.run(debug=True)
